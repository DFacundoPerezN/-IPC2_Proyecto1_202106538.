
class Celda:
    def __init__(self, fila, columna):
        self.fila = fila
        self.columna= columna
        